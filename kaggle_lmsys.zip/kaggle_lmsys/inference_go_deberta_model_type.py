from pathlib import Path

import click
import torch
import numpy as np
from datasets import Dataset
from transformers import AutoTokenizer

from utils import clean_data
from utils import tokenization_prompt_one_resp
from utils import get_device
from utils import Collator
from models.deberta_classifier import CustomizedDetertaClassifier

SEED = 123
random_state = np.random.RandomState(SEED)
torch.manual_seed(0)
torch_gen = torch.Generator()
torch_gen.manual_seed(0)
numpy_gen = np.random.Generator(np.random.PCG64(seed=SEED))
device = get_device()


@click.command()
@click.option('--for_test', type=bool, default=False, required=True)
def go(for_test: bool):
    data_config = {
        "train_data_path": "/kaggle/input/lmsys-chatbot-arena/train.csv",
        "prompt": "prompt",
        "resp_a": "response_a",
        "resp_b": "response_b",
        "resp_a_win": "winner_model_a",
        "resp_b_win": "winner_model_b",
        "resp_tie": "winner_tie",
        "added_target_field": "label",
    }
    model_config = {
        "model_name": "google/gemma-2b-it",
        "num_labels": 3,
        "train_pct": 0.8,
        "eval_pct": 0.2,
        "cv": 4,
        "max_length": 512,
        "learning_rate": 7.0e-06,
        "train_batch_size": 4,
        "num_gradient_update_batch": 4,
        "num_epoch": 1,
        "output_path": "model_output",

    }
    inference_config = {
        "data_path": "/kaggle/input/lmsys-chatbot-arena/test.csv",
        "tokenizer_path": "/kaggle/input/lmsys-go-deberta-model-type-model-outputs/model_type_classifier_output",
        "model_path": "/kaggle/input/lmsys-go-deberta-model-type-model-outputs/model_type_classifier_output",
        "output_path": "/kaggle/working/submission.csv",
    }
    tokenizer = AutoTokenizer.from_pretrained(
        inference_config["tokenizer_path"]
    )
    model = CustomizedDetertaClassifier.from_pretrained(
        inference_config["model_path"]

    )
    model.to(device)

    data_path = Path(inference_config["data_path"])
    input_fields = [data_config["prompt"], data_config["resp_a"], data_config["resp_b"]]
    data = clean_data(data_path, input_fields)
    if for_test:
        data = data.iloc[: 10, :]
    dataset = Dataset.from_pandas(data)
    dataset.cleanup_cache_files()
    tokenization_args = {
        "tokenizer": tokenizer,
        "max_length": 512,
        "prompt_field": data_config["prompt"],
        "resp_field": data_config["resp_a"],
        "target_field": None,
    }
    dataset = dataset.map(
        function=tokenization_prompt_one_resp,
        batched=False,
        fn_kwargs=tokenization_args,
        remove_columns=dataset.column_names,
    )
    data_collator = Collator(
        tokenizer,
        max_length=model_config["max_length"],
    )

    model_types = []
    for row_id, data in enumerate(dataset):
        preds = model(**data_collator([data]))
        preds = torch.nn.functional.softmax(preds.logits.cuda(), dim=-1)
        model_type = torch.argmax(preds, axis=1)
        model_types.append(model_type)

    model_types = torch.vstack(model_types).flatten()
    model_types = model_types.detach().cpu().numpy()


if __name__ == "__main__":
    # ! python /kaggle/working/go.py --for_test=True
    go()
