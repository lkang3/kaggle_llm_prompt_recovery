from enum import auto
from enum import Enum


class DataType(Enum):
    NUM = auto()
    CAT = auto()
    TXT = auto()
